#include <stdint.h>
#include <stdbool.h>
#include <pthread.h>
#include <sys/stat.h>
/* #include <getopt.h> */
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>



int main(int argc, char* argv[]) {
    
   system("./t1");
   
  return 0;  
}
    